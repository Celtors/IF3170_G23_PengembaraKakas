type Vector3Type = [number, number, number]

export interface Package3DModel {
    id: string;
    position: Vector3Type;
    dimension: Vector3Type;
    color: string;
}

export interface Truck3DModel {
    weight: number;
    length: number;
    height: number;
}

import type { Package3DModel } from "../types";

export function RenderPackage (props: ThreeElements["mesh"], {
    position, dimension, color
}: Package3DModel) {
    const center: Package3DModel = [
        position[0] + dimension[0]/2,
        position[1] + dimension[1]/2,
        position[2] + dimension[2]/2
    ]
    return (
        <mesh position={center}>

        </mesh>
    )
}